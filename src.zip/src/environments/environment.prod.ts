export const environment = {
  production: true,
  base_url: 'https://sadl-kuleuven.github.io/resist/#/home',
  cases_json_url: 'https://raw.githubusercontent.com/sadl-kuleuven/resist/main/src/assets/cases.json'
  //cases_json_url: 'assets/cases.json'
};
