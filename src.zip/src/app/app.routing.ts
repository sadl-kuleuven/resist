import { NgModule } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { DelineationComponent } from './views/delineation/delineation.component';

import { MainComponent } from './views/main/main.component';

const routes: Routes = [
  { path: 'main', component: MainComponent },
  { path: 'home', redirectTo: 'main', pathMatch: 'full' }, 
  { path: 'delineation', component: DelineationComponent },
  { path: '', redirectTo: '/main', pathMatch: 'full' }
];

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(routes, { useHash: true }) 
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
